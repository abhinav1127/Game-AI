import os

# The root directory of the bulk homework submission download.
root = "Homework 2"
root = os.path.join(".", root)

# Whether to suppress print statements while grading homework.
disablePrint = True

# The number of seconds to allow student code to run before timing out. Set to None to disable timeout.
timeout = 300